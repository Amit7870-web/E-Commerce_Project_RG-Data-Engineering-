# Databricks notebook source
from pyspark.sql.functions import *

# COMMAND ----------

# MAGIC %md
# MAGIC ## Crate a Widget for incremental run

# COMMAND ----------

dbutils.widgets.text("incremental flag" , "0")

# COMMAND ----------

# MAGIC %md
# MAGIC ## check incremental run 

# COMMAND ----------

incremental_flag= dbutils.widgets.get("incremental flag")
incremental_flag


# COMMAND ----------

# MAGIC %md
# MAGIC ### Establish connection with ADLS

# COMMAND ----------

spark.conf.set("fs.azure.account.key.storageaccountecommer.dfs.core.windows.net","7uRmvvy/L1ramWo0r6K/y/a1J+s4lJtMTsfcCrKAlHbi9y+/9i0asWZSxR/XNC7e6vvw5bt7XGST+AStk1QPxA==")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Check connection

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from parquet.`abfss://silver@storageaccountecommer.dfs.core.windows.net/silverdata`

# COMMAND ----------

# MAGIC %md
# MAGIC ## Working on SalesRegion Dimension

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct(SalesRegion) as SalesRegion from parquet.`abfss://silver@storageaccountecommer.dfs.core.windows.net/silverdata`
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Create a DataFrame - df_src

# COMMAND ----------

df_src = spark.sql("""
select distinct(SalesRegion) as SalesRegion from parquet.`abfss://silver@storageaccountecommer.dfs.core.windows.net/silverdata`
""")
df_src.display()

# COMMAND ----------

df_src.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Getting gold layer data - df_sink

# COMMAND ----------

from delta.tables import DeltaTable

path = "abfss://gold@storageaccountecommer.dfs.core.windows.net/dim_region"

if DeltaTable.isDeltaTable(spark, path):
    df_sink = spark.sql(
        """
        select Dim_Region_Key,SalesRegion from delta.`abfss://gold@storageaccountecommer.dfs.core.windows.net/dim_region`
        """
    )
    print("table exists")
else:
    # df_sink = spark.sql(
    #     """
    #     select 1 as Dim_Region_Key,SalesRegion from parquet.`abfss://silver@storageaccountecommer.dfs.core.windows.net/silverdata` where 1=2
    #     """
    # )
    df_sink = spark.createDataFrame([], schema="Dim_Region_Key int, SalesRegion string")

    df_sink.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Old and new record -left join 

# COMMAND ----------

df = df_src.join(df_sink, df_src['SalesRegion']==df_sink['SalesRegion'], 'left').select(df_src['SalesRegion'], df_sink['Dim_Region_Key'])
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Old Records

# COMMAND ----------

df_old = df.filter(df["Dim_Region_Key"].isNotNull())
df_old.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## New Records

# COMMAND ----------

df_new = df.filter(df['Dim_Region_Key'].isNull())
df_new.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Get Maximum Dim_Region_Key

# COMMAND ----------

if incremental_flag == '0':
    max_value = 1
else:
    max_value = df_old.select(max(df_old['Dim_Region_Key'])).collect()[0][0]

max_value

# COMMAND ----------

# MAGIC %md
# MAGIC ## Create Surrogate Key

# COMMAND ----------

from pyspark.sql.functions import monotonically_increasing_id

df = df.withColumn('Dim_Region_Key', max_value + monotonically_increasing_id())
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Union new and old

# COMMAND ----------

df = df_old.union(df)
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Final part 
# MAGIC
# MAGIC
# MAGIC ### SCD type 1 - upsert 

# COMMAND ----------

# ACID Transactions - Atomicity Consistency Isolation Durability
from delta.tables import DeltaTable

table_name = 'gold.dim_Region'
path = 'abfss://gold@storageaccountecommer.dfs.core.windows.net/dim_Region'

if DeltaTable.isDeltaTable(spark, path):
    deltaTable = DeltaTable.forPath(spark, path)
    deltaTable.alias('target').merge(df.alias('source'), 'target.Dim_Region_Key = source.Dim_Region_Key').whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()
    print("Good")
else:
    df.write.format('delta').mode('overwrite').option('mergeSchema', "true").save(path)
    print('The table is created')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from delta.`abfss://gold@storageaccountecommer.dfs.core.windows.net/dim_Region`