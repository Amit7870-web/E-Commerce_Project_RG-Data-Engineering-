# Databricks notebook source
from pyspark.sql.functions import *

# COMMAND ----------

spark.conf.set("fs.azure.account.key.storageaccountecommer.dfs.core.windows.net","7uRmvvy/L1ramWo0r6K/y/a1J+s4lJtMTsfcCrKAlHbi9y+/9i0asWZSxR/XNC7e6vvw5bt7XGST+AStk1QPxA==")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load All Dimension

# COMMAND ----------

# MAGIC %md
# MAGIC ### Customer Dimension

# COMMAND ----------

df_customer = spark.sql( """
SELECT * FROM delta.`abfss://gold@storageaccountecommer.dfs.core.windows.net/dim_Customer` """
)

df_customer.display()

# COMMAND ----------

df_customer.groupBy('CustomerID').count().filter('count > 1').display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Product Dimension

# COMMAND ----------

df_product = spark.sql( """
SELECT * FROM delta.`abfss://gold@storageaccountecommer.dfs.core.windows.net/dim_Product` """
)
df_product.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Date Dimension

# COMMAND ----------

df_date = spark.sql( """
SELECT * FROM delta.`abfss://gold@storageaccountecommer.dfs.core.windows.net/dim_Date` """
)
df_date.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Region Dimension

# COMMAND ----------

df_region = spark.sql( """
SELECT * FROM delta.`abfss://gold@storageaccountecommer.dfs.core.windows.net/dim_Region` """
)
df_region.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Load Silver Data

# COMMAND ----------

silver_df = spark.sql( """
SELECT * FROM PARQUET.`abfss://silver@storageaccountecommer.dfs.core.windows.net/silverdata` """
)
silver_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Create a Fact Table

# COMMAND ----------

fact_df = silver_df.join(df_customer, silver_df['CustomerID']==df_customer['CustomerID'], 'left') \
    .join(df_product, silver_df['ProductID']==df_product['ProductID'], 'left') \
    .join(df_date, silver_df['OrderDate']==df_date['OrderDate'], 'left') \
    .join(df_region, silver_df['SalesRegion']==df_region['SalesRegion'], 'left') \
    .select(
        df_customer['Dim_Customer_Key'],
        df_product['Dim_Product_Key'],
        df_date['Dim_Date_Key'],
        df_region['Dim_Region_Key'],
        silver_df['UnitPrice'],
        silver_df['TotalPrice'],
        silver_df['Quantity']
    )

fact_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## SCD type 1 - upsert

# COMMAND ----------

# ACID Transactions - Atomicity Consistency Isolation Durability
from delta.tables import DeltaTable

table_name = 'gold.dim_factsales'
path = 'abfss://gold@storageaccountecommer.dfs.core.windows.net/dim_factsales'

if DeltaTable.isDeltaTable(spark, path):
    deltaTable = DeltaTable.forPath(spark, path)
    deltaTable.alias('target').merge(
        fact_df.alias('source'),
        'target.Dim_Customer_Key==source.Dim_Customer_Key and target.Dim_Product_Key==source.Dim_Product_Key and target.Dim_Date_Key==source.Dim_Date_Key and target.Dim_Region_Key==source.Dim_Region_Key'
    ).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()
    print('good')
else:
    fact_df.write.format('delta').mode('overwrite').option('mergeSchema', "true").save(path)
    print('The table is created')