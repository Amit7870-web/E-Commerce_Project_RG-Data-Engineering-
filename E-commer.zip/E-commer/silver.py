# Databricks notebook source
from pyspark.sql.functions import *

# COMMAND ----------

# MAGIC %md
# MAGIC # Stablish connection

# COMMAND ----------

spark.conf.set("fs.azure.account.key.storageaccountecommer.dfs.core.windows.net","7uRmvvy/L1ramWo0r6K/y/a1J+s4lJtMTsfcCrKAlHbi9y+/9i0asWZSxR/XNC7e6vvw5bt7XGST+AStk1QPxA==")

# COMMAND ----------

filename = dbutils.fs.ls("abfss://bronze@storageaccountecommer.dfs.core.windows.net")[0].name 
filename

# COMMAND ----------

df = spark.read.parquet(f"abfss://bronze@storageaccountecommer.dfs.core.windows.net/{filename}")
df.display()


# COMMAND ----------

df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC ### convert into Tittle case - initcap

# COMMAND ----------

df = df.withColumn("Country" , initcap(df["Country"]))
df = df.withColumn("ProductCategory" , initcap(df["ProductCategory"]))
df = df.withColumn("ProductName" , initcap(df["ProductName"]))
df = df.withColumn("SalesRegion" , initcap(df["SalesRegion"]))
df = df.withColumn("CustomerName" , initcap(df["CustomerName"]))
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Remove the raw , where all of the value are missing 

# COMMAND ----------

df = df.dropna(how='all')
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Remove duplicate rows

# COMMAND ----------

df = df.dropDuplicates()
df.display()

# COMMAND ----------

df.write.format('parquet').mode('overwrite').option("path","abfss://silver@storageaccountecommer.dfs.core.windows.net/silverdata").save()